# Untranslated Report

Fehlende oder unvollständige Übersetzungen nach Sprachen und Keys.
