# 🏁 Flaggenverzeichnis

Speichere hier Flaggen für alle unterstützten Sprachen im Format:

```
/static/flags/en.png
/static/flags/de.png
...
```

Empfohlenes Format: 28x20px PNG  
Quelle z. B.: https://flagcdn.com oder https://hatscripts.github.io/circle-flags/