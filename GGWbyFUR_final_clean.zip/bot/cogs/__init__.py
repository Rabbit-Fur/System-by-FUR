# Dieser Ordner enthält die Cogs (Module) für den Discord Bot.
