from flask import Blueprint

from . import routes

public_bp = Blueprint(
    "public",
    __name__,
    template_folder="templates/public",
    # Nutzt globale static Files
    url_prefix="/",  # Kein Prefix für öffentliche Hauptseiten
)

# Routen importieren
